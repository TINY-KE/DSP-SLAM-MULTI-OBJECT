轨迹真值  cam_traj_2025-03-04_22-34-04

对应rosbag：living_room_my.bag